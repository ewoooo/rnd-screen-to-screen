"use client";

import {
	createContext,
	type CSSProperties,
	type ElementType,
	type ReactNode,
	useContext,
} from "react";
import { createScreenExportAttributes } from "../screen-export";

export type ContentLayoutMode = "legacy" | "screen";
export type ContentSectionInset = "inherit" | "bleed";
export type ContentRailKind = "full" | "inset" | "measure";
export type ContentRailMeasure = "title" | "body" | "caption";

type ContentLayoutContextValue = {
	inlineInset: string;
	sectionInset: ContentSectionInset;
};

const ContentLayoutContext = createContext<ContentLayoutContextValue>({
	inlineInset: "0px",
	sectionInset: "inherit",
});

export function ContentLayoutProvider({
	inlineInset,
	children,
}: {
	inlineInset: string;
	children: ReactNode;
}) {
	return (
		<ContentLayoutContext.Provider
			value={{ inlineInset, sectionInset: "inherit" }}
		>
			{children}
		</ContentLayoutContext.Provider>
	);
}

function useContentInsetContext() {
	return useContext(ContentLayoutContext);
}

export function ContentSection({
	as = "section",
	inset = "inherit",
	children,
	exportNode,
	style,
}: {
	as?: ElementType;
	inset?: ContentSectionInset;
	children: ReactNode;
	exportNode?: {
		type: string;
		id?: string;
		props?: Record<string, unknown>;
	};
	style?: CSSProperties;
}) {
	const { inlineInset } = useContentInsetContext();
	const bleedStyle =
		inset === "bleed"
			? {
					marginLeft: `calc(-1 * ${inlineInset})`,
					marginRight: `calc(-1 * ${inlineInset})`,
				}
			: null;

	return (
		<Element
			as={as}
			exportAttributes={createScreenExportAttributes({
				type: exportNode?.type ?? "ContentSection",
				id: exportNode?.id,
				props: { inset, ...(exportNode?.props ?? {}) },
			})}
			style={{ ...bleedStyle, ...style }}
		>
			<ContentLayoutContext.Provider
				value={{ inlineInset, sectionInset: inset }}
			>
				{children}
			</ContentLayoutContext.Provider>
		</Element>
	);
}

const measureWidth: Record<ContentRailMeasure, string> = {
	title: "18ch",
	body: "34ch",
	caption: "28ch",
};

export function ContentRail({
	as = "div",
	rail = "inset",
	measure = "body",
	children,
	style,
}: {
	as?: ElementType;
	rail?: ContentRailKind;
	measure?: ContentRailMeasure;
	children: ReactNode;
	style?: CSSProperties;
}) {
	const { inlineInset, sectionInset } = useContentInsetContext();
	const shouldRestoreInset = sectionInset === "bleed" && rail !== "full";
	const maxWidth =
		rail === "measure"
			? shouldRestoreInset
				? `calc(${measureWidth[measure]} + (${inlineInset} * 2))`
				: measureWidth[measure]
			: undefined;

	return (
		<Element
			as={as}
			exportAttributes={createScreenExportAttributes({
				type: "ContentRail",
				props: { rail, measure },
			})}
			style={{
				boxSizing: "border-box",
				width: "100%",
				...(shouldRestoreInset ? { paddingInline: inlineInset } : null),
				...(maxWidth ? { maxWidth } : null),
				...style,
			}}
		>
			{children}
		</Element>
	);
}

function Element({
	as: As,
	children,
	style,
	exportAttributes,
}: {
	as: ElementType;
	children: ReactNode;
	style?: CSSProperties;
	exportAttributes?: Record<string, string>;
}) {
	return (
		<As style={style} {...exportAttributes}>
			{children}
		</As>
	);
}
