import { AppBar, StatusBar } from "@pxds/cx-components";
import { AppScreen } from "@pxds/pxds-layout/app-screen";
import { SectionHeaderPage, TextFieldMemberInfo } from "@/organisms/mbr";

export function Screen() {
	return (
		<AppScreen>
			<AppScreen.SystemHeader>
				<StatusBar />
			</AppScreen.SystemHeader>
			<AppScreen.Header>
				<AppBar title="회원 가입" showLeftItem showTitle />
			</AppScreen.Header>
			<AppScreen.Content>
				<SectionHeaderPage title="개인정보 입력" />
				<TextFieldMemberInfo />
			</AppScreen.Content>
		</AppScreen>
	);
}
